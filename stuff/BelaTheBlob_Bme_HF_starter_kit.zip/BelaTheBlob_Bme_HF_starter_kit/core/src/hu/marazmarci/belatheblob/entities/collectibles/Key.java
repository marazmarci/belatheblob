package hu.marazmarci.belatheblob.entities.collectibles;


public abstract class Key extends Collectible {

}
