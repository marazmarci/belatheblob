package hu.marazmarci.belatheblob.entities.collectibles;


public abstract class Crystal extends Collectible {

}
